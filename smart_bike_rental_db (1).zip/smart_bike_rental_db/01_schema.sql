-- =====================================================================
-- Smart Bike Rental App - Integrated PostgreSQL schema (Person 5)
-- Combines Person 1-4 scripts and aligns every table to the ERD.
-- Creation order respects foreign-key dependencies:
--   users -> rider_verifications, docking_stations -> bikes,
--   pricing_plans -> rentals -> damage_reports, notifications
-- Run on an empty database:  psql -d bikerental -f 01_schema.sql
-- =====================================================================

DROP TABLE IF EXISTS notifications        CASCADE;
DROP TABLE IF EXISTS damage_reports       CASCADE;
DROP TABLE IF EXISTS rentals              CASCADE;
DROP TABLE IF EXISTS pricing_plans        CASCADE;
DROP TABLE IF EXISTS bikes                CASCADE;
DROP TABLE IF EXISTS docking_stations     CASCADE;
DROP TABLE IF EXISTS rider_verifications  CASCADE;
DROP TABLE IF EXISTS users                CASCADE;

-- ---------------------------------------------------------------------
-- 1. USERS (Person 1) - script was missing; built from the ERD
-- ---------------------------------------------------------------------
CREATE TABLE users (
    user_id        BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    full_name      VARCHAR(120)  NOT NULL,
    email          VARCHAR(255)  NOT NULL UNIQUE,
    password_hash  TEXT          NOT NULL,
    role           VARCHAR(20)   NOT NULL DEFAULT 'rider',
    created_at     TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    updated_at     TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_users_role CHECK (role IN ('rider', 'admin'))
);

-- ---------------------------------------------------------------------
-- 2. RIDER_VERIFICATIONS (Person 1)
-- ---------------------------------------------------------------------
CREATE TABLE rider_verifications (
    verification_id       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    rider_id              BIGINT       NOT NULL,
    document_reference    TEXT         NOT NULL,
    verification_status   VARCHAR(20)  NOT NULL DEFAULT 'pending',
    rejection_reason      TEXT,
    submitted_at          TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    reviewed_at           TIMESTAMPTZ,
    reviewed_by_admin_id  BIGINT,
    CONSTRAINT fk_verification_rider FOREIGN KEY (rider_id)
        REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_verification_admin FOREIGN KEY (reviewed_by_admin_id)
        REFERENCES users(user_id) ON DELETE SET NULL,
    CONSTRAINT chk_verification_status
        CHECK (verification_status IN ('pending', 'approved', 'rejected')),
    CONSTRAINT chk_verification_rejection
        CHECK (verification_status <> 'rejected' OR rejection_reason IS NOT NULL),
    CONSTRAINT chk_verification_reviewed
        CHECK (verification_status = 'pending' OR reviewed_at IS NOT NULL)
);

-- ---------------------------------------------------------------------
-- 3. DOCKING_STATIONS (Person 2)
-- ---------------------------------------------------------------------
CREATE TABLE docking_stations (
    station_id           BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    station_name         VARCHAR(120)  NOT NULL,
    location_description TEXT          NOT NULL,
    latitude             NUMERIC(9,6),
    longitude            NUMERIC(9,6),
    station_status       VARCHAR(20)   NOT NULL DEFAULT 'active',
    created_at           TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_station_status
        CHECK (station_status IN ('active', 'inactive', 'maintenance')),
    CONSTRAINT chk_station_lat CHECK (latitude  IS NULL OR latitude  BETWEEN -90  AND 90),
    CONSTRAINT chk_station_lon CHECK (longitude IS NULL OR longitude BETWEEN -180 AND 180)
);

-- ---------------------------------------------------------------------
-- 4. BIKES (Person 2)
-- ---------------------------------------------------------------------
CREATE TABLE bikes (
    bike_id             BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    qr_code             VARCHAR(255) NOT NULL UNIQUE,
    bike_status         VARCHAR(20)  NOT NULL DEFAULT 'available',
    current_station_id  BIGINT,
    added_at            TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_bike_station FOREIGN KEY (current_station_id)
        REFERENCES docking_stations(station_id),
    CONSTRAINT chk_bike_status
        CHECK (bike_status IN ('available', 'rented', 'maintenance', 'damaged'))
);

-- ---------------------------------------------------------------------
-- 5. PRICING_PLANS (Person 3)
-- ---------------------------------------------------------------------
CREATE TABLE pricing_plans (
    pricing_plan_id   BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    plan_name         VARCHAR(100)  NOT NULL UNIQUE,
    plan_type         VARCHAR(20)   NOT NULL,
    price             NUMERIC(10,2) NOT NULL,
    currency_code     CHAR(3)       NOT NULL DEFAULT 'EGP',
    duration_minutes  INTEGER,
    is_active         BOOLEAN       NOT NULL DEFAULT TRUE,
    created_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_plan_type  CHECK (plan_type IN ('pay_per_ride', 'day_pass', 'monthly')),
    CONSTRAINT chk_plan_price CHECK (price >= 0),
    CONSTRAINT chk_plan_duration CHECK (duration_minutes IS NULL OR duration_minutes > 0)
);

-- ---------------------------------------------------------------------
-- 6. RENTALS (Person 3)
-- ---------------------------------------------------------------------
CREATE TABLE rentals (
    rental_id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    rider_id          BIGINT        NOT NULL,
    bike_id           BIGINT        NOT NULL,
    pricing_plan_id   BIGINT        NOT NULL,
    start_station_id  BIGINT,
    end_station_id    BIGINT,
    rental_status     VARCHAR(20)   NOT NULL DEFAULT 'requested',
    requested_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    start_time        TIMESTAMPTZ,
    end_time          TIMESTAMPTZ,
    cancelled_at      TIMESTAMPTZ,
    total_cost        NUMERIC(10,2),
    CONSTRAINT fk_rental_rider   FOREIGN KEY (rider_id)         REFERENCES users(user_id),
    CONSTRAINT fk_rental_bike    FOREIGN KEY (bike_id)          REFERENCES bikes(bike_id),
    CONSTRAINT fk_rental_plan    FOREIGN KEY (pricing_plan_id)  REFERENCES pricing_plans(pricing_plan_id),
    CONSTRAINT fk_rental_start   FOREIGN KEY (start_station_id) REFERENCES docking_stations(station_id),
    CONSTRAINT fk_rental_end     FOREIGN KEY (end_station_id)   REFERENCES docking_stations(station_id),
    CONSTRAINT chk_rental_status
        CHECK (rental_status IN ('requested', 'active', 'completed', 'cancelled')),
    CONSTRAINT chk_rental_time   CHECK (end_time IS NULL OR (start_time IS NOT NULL AND end_time > start_time)),
    CONSTRAINT chk_rental_cost   CHECK (total_cost IS NULL OR total_cost >= 0),
    CONSTRAINT chk_rental_cancel CHECK ((rental_status = 'cancelled') = (cancelled_at IS NOT NULL))
);

-- ---------------------------------------------------------------------
-- 7. DAMAGE_REPORTS (Person 4)
-- ---------------------------------------------------------------------
CREATE TABLE damage_reports (
    report_id             BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    bike_id               BIGINT       NOT NULL,
    rider_id              BIGINT       NOT NULL,
    description           TEXT         NOT NULL,
    report_status         VARCHAR(20)  NOT NULL DEFAULT 'open',
    reported_at           TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    reviewed_by_admin_id  BIGINT,
    reviewed_at           TIMESTAMPTZ,
    CONSTRAINT fk_damage_bike  FOREIGN KEY (bike_id)  REFERENCES bikes(bike_id) ON DELETE RESTRICT,
    CONSTRAINT fk_damage_rider FOREIGN KEY (rider_id) REFERENCES users(user_id) ON DELETE RESTRICT,
    CONSTRAINT fk_damage_admin FOREIGN KEY (reviewed_by_admin_id)
        REFERENCES users(user_id) ON DELETE SET NULL,
    CONSTRAINT chk_damage_status CHECK (report_status IN ('open', 'in_review', 'resolved'))
);

-- ---------------------------------------------------------------------
-- 8. NOTIFICATIONS (Person 4)
-- ---------------------------------------------------------------------
CREATE TABLE notifications (
    notification_id    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id            BIGINT       NOT NULL,
    rental_id          BIGINT,
    notification_type  VARCHAR(30)  NOT NULL,
    message            TEXT         NOT NULL,
    created_at         TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    read_at            TIMESTAMPTZ,
    CONSTRAINT fk_notif_user   FOREIGN KEY (user_id)   REFERENCES users(user_id)     ON DELETE CASCADE,
    CONSTRAINT fk_notif_rental FOREIGN KEY (rental_id) REFERENCES rentals(rental_id) ON DELETE SET NULL,
    CONSTRAINT chk_notif_type CHECK (notification_type IN
        ('rental_started', 'rental_ended', 'payment', 'damage_update', 'system'))
);

-- Indexes on foreign keys that are queried often
CREATE INDEX idx_rentals_rider   ON rentals(rider_id);
CREATE INDEX idx_rentals_bike    ON rentals(bike_id);
CREATE INDEX idx_bikes_station   ON bikes(current_station_id);
CREATE INDEX idx_damage_bike     ON damage_reports(bike_id);
CREATE INDEX idx_notif_user      ON notifications(user_id);
