-- Sample data for all 8 tables. Run after 01_schema.sql.
-- Identity columns are GENERATED ALWAYS, so ids are assigned 1,2,3... in insert order.

INSERT INTO users (full_name, email, password_hash, role) VALUES
 ('Admin Salma Nabil',  'salma.admin@bikeapp.test',  '$2b$12$hashadmin1xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', 'admin'),   -- 1
 ('Admin Karim Fathy',  'karim.admin@bikeapp.test',  '$2b$12$hashadmin2xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', 'admin'),   -- 2
 ('Ahmed Hassan',       'ahmed.hassan@bikeapp.test', '$2b$12$hashrider1xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', 'rider'),   -- 3
 ('Mona Ali',           'mona.ali@bikeapp.test',     '$2b$12$hashrider2xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', 'rider'),   -- 4
 ('Omar Youssef',       'omar.youssef@bikeapp.test', '$2b$12$hashrider3xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', 'rider'),   -- 5
 ('Laila Mostafa',      'laila.m@bikeapp.test',      '$2b$12$hashrider4xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', 'rider');   -- 6

INSERT INTO rider_verifications
 (rider_id, document_reference, verification_status, rejection_reason, submitted_at, reviewed_at, reviewed_by_admin_id) VALUES
 (3, 'NID-29901011234567', 'approved', NULL,                       NOW() - INTERVAL '30 days', NOW() - INTERVAL '29 days', 1),
 (4, 'NID-29505051234568', 'approved', NULL,                       NOW() - INTERVAL '25 days', NOW() - INTERVAL '24 days', 2),
 (5, 'PASSPORT-A1234567',  'rejected', 'Document photo is blurry', NOW() - INTERVAL '10 days', NOW() - INTERVAL '9 days',  1),
 (6, 'NID-30001011234569', 'pending',  NULL,                       NOW() - INTERVAL '1 day',   NULL,                       NULL);

INSERT INTO docking_stations
 (station_name, location_description, latitude, longitude, station_status) VALUES
 ('Tahrir Square Station',  'Next to the Egyptian Museum, north entrance',  30.044420, 31.235712, 'active'),       -- 1
 ('Zamalek Corniche',       'Nile Corniche opposite the Cairo Tower',        30.061700, 31.224500, 'active'),       -- 2
 ('Cairo University Gate',  'Main gate, Giza side',                          30.026100, 31.208500, 'active'),       -- 3
 ('Maadi Grand Mall',       'Parking entrance, Road 9',                      29.960100, 31.257000, 'maintenance');  -- 4

INSERT INTO bikes (qr_code, bike_status, current_station_id) VALUES
 ('QR-BIKE-0001', 'available',   1),     -- 1
 ('QR-BIKE-0002', 'available',   1),     -- 2
 ('QR-BIKE-0003', 'rented',      NULL),  -- 3 (out on an active rental)
 ('QR-BIKE-0004', 'available',   2),     -- 4
 ('QR-BIKE-0005', 'damaged',     3),     -- 5
 ('QR-BIKE-0006', 'maintenance', 4);     -- 6

INSERT INTO pricing_plans (plan_name, plan_type, price, currency_code, duration_minutes, is_active) VALUES
 ('Pay Per Ride 30',  'pay_per_ride', 15.00,  'EGP', 30,    TRUE),   -- 1
 ('Day Pass',         'day_pass',     60.00,  'EGP', 1440,  TRUE),   -- 2
 ('Monthly Unlimited','monthly',      350.00, 'EGP', 43200, TRUE),   -- 3
 ('Student Special',  'monthly',      200.00, 'EGP', 43200, FALSE);  -- 4 (retired plan)

INSERT INTO rentals
 (rider_id, bike_id, pricing_plan_id, start_station_id, end_station_id, rental_status,
  requested_at, start_time, end_time, cancelled_at, total_cost) VALUES
 -- completed ride
 (3, 1, 1, 1, 2, 'completed', NOW() - INTERVAL '3 days 5 minutes', NOW() - INTERVAL '3 days',
      NOW() - INTERVAL '3 days' + INTERVAL '25 minutes', NULL, 15.00),                       -- 1
 -- active ride (bike 3 is out)
 (4, 3, 2, 3, NULL, 'active', NOW() - INTERVAL '2 hours 5 minutes', NOW() - INTERVAL '2 hours', NULL, NULL, NULL), -- 2
 -- cancelled before start
 (3, 2, 1, 1, NULL, 'cancelled', NOW() - INTERVAL '1 day', NULL, NULL, NOW() - INTERVAL '1 day' + INTERVAL '2 minutes', NULL), -- 3
 -- just requested, no station yet
 (4, 4, 3, NULL, NULL, 'requested', NOW() - INTERVAL '1 minute', NULL, NULL, NULL, NULL),  -- 4
 -- completed ride that ended in damage
 (3, 5, 2, 2, 3, 'completed', NOW() - INTERVAL '6 days 5 minutes', NOW() - INTERVAL '6 days',
      NOW() - INTERVAL '6 days' + INTERVAL '50 minutes', NULL, 60.00);                       -- 5

INSERT INTO damage_reports
 (bike_id, rider_id, description, report_status, reported_at, reviewed_by_admin_id, reviewed_at) VALUES
 (5, 3, 'Front brake lever is loose and the chain is rattling.', 'in_review', NOW() - INTERVAL '6 days', 1, NOW() - INTERVAL '5 days'),
 (5, 3, 'Rear tyre has a puncture.',                             'open',      NOW() - INTERVAL '5 days', NULL, NULL),
 (1, 4, 'Seat is stuck at the lowest height.',                   'resolved',  NOW() - INTERVAL '12 days', 2, NOW() - INTERVAL '11 days');

INSERT INTO notifications (user_id, rental_id, notification_type, message, read_at) VALUES
 (3, 1,    'rental_started', 'Your rental has started. Enjoy the ride!',          NOW() - INTERVAL '3 days'),
 (3, 1,    'rental_ended',   'Ride finished. Duration 25 min.',                   NOW() - INTERVAL '3 days'),
 (3, 1,    'payment',        'Payment of 15.00 EGP received.',                    NULL),
 (4, 2,    'rental_started', 'Your rental has started. Enjoy the ride!',          NULL),
 (3, NULL, 'damage_update',  'Your damage report is now under review.',           NULL),
 (6, NULL, 'system',         'Your verification is pending review.',              NULL);
