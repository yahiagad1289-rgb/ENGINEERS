-- Valid / invalid entry tests. Run after 01_schema.sql and 02_sample_data.sql.
-- Everything runs inside a transaction that is rolled back, so the sample data is untouched.
-- Each test prints PASS or FAIL.  expect_ok  = statement must succeed.
--                                expect_fail = statement must be rejected by the database.

BEGIN;

CREATE TEMP TABLE test_results (id SERIAL, kind TEXT, label TEXT, outcome TEXT, detail TEXT);

CREATE FUNCTION expect_ok(p_label TEXT, p_sql TEXT) RETURNS VOID AS $$
DECLARE v_err TEXT := NULL;
BEGIN
    BEGIN
        EXECUTE p_sql;
        RAISE EXCEPTION 'rollback_test';          -- undo the test insert
    EXCEPTION WHEN OTHERS THEN
        IF SQLERRM <> 'rollback_test' THEN v_err := SQLERRM; END IF;
    END;
    -- recorded here, outside the rolled-back sub-block
    INSERT INTO test_results(kind,label,outcome,detail)
    VALUES ('valid', p_label, CASE WHEN v_err IS NULL THEN 'PASS' ELSE 'FAIL' END, v_err);
END $$ LANGUAGE plpgsql;

CREATE FUNCTION expect_fail(p_label TEXT, p_sql TEXT) RETURNS VOID AS $$
DECLARE v_err TEXT := NULL;
BEGIN
    BEGIN
        EXECUTE p_sql;
        RAISE EXCEPTION 'rollback_test';
    EXCEPTION WHEN OTHERS THEN
        IF SQLERRM <> 'rollback_test' THEN v_err := SQLERRM; END IF;
    END;
    INSERT INTO test_results(kind,label,outcome,detail)
    VALUES ('invalid', p_label, CASE WHEN v_err IS NULL THEN 'FAIL' ELSE 'PASS' END,
            COALESCE(v_err, 'statement was accepted'));
END $$ LANGUAGE plpgsql;

-- ------------------------------ VALID ENTRIES ------------------------------
SELECT expect_ok('users: new rider',
  $$INSERT INTO users(full_name,email,password_hash,role) VALUES ('Test Rider','t1@x.test','h','rider')$$);
SELECT expect_ok('rider_verifications: pending submission',
  $$INSERT INTO rider_verifications(rider_id,document_reference) VALUES (6,'NID-NEW-1')$$);
SELECT expect_ok('docking_stations: station with no coordinates',
  $$INSERT INTO docking_stations(station_name,location_description) VALUES ('New St','Somewhere')$$);
SELECT expect_ok('bikes: bike with no station (in use)',
  $$INSERT INTO bikes(qr_code,bike_status) VALUES ('QR-NEW-1','rented')$$);
SELECT expect_ok('pricing_plans: new plan',
  $$INSERT INTO pricing_plans(plan_name,plan_type,price,duration_minutes) VALUES ('Weekend','day_pass',40,2880)$$);
SELECT expect_ok('rentals: requested rental, no stations yet',
  $$INSERT INTO rentals(rider_id,bike_id,pricing_plan_id) VALUES (4,2,1)$$);
SELECT expect_ok('damage_reports: report without reviewer',
  $$INSERT INTO damage_reports(bike_id,rider_id,description) VALUES (2,4,'Bell is missing')$$);
SELECT expect_ok('notifications: system notification without rental',
  $$INSERT INTO notifications(user_id,notification_type,message) VALUES (4,'system','Hello')$$);

-- ----------------------------- INVALID ENTRIES -----------------------------
-- users
SELECT expect_fail('users: duplicate email (UNIQUE)',
  $$INSERT INTO users(full_name,email,password_hash,role) VALUES ('Dup','ahmed.hassan@bikeapp.test','h','rider')$$);
SELECT expect_fail('users: invalid role (CHECK)',
  $$INSERT INTO users(full_name,email,password_hash,role) VALUES ('X','x@x.test','h','superuser')$$);
SELECT expect_fail('users: NULL email (NOT NULL)',
  $$INSERT INTO users(full_name,email,password_hash) VALUES ('X',NULL,'h')$$);
-- rider_verifications
SELECT expect_fail('rider_verifications: rider_id does not exist (FK)',
  $$INSERT INTO rider_verifications(rider_id,document_reference) VALUES (9999,'D')$$);
SELECT expect_fail('rider_verifications: reviewed_by_admin_id does not exist (FK)',
  $$INSERT INTO rider_verifications(rider_id,document_reference,verification_status,reviewed_at,reviewed_by_admin_id) VALUES (6,'D','approved',NOW(),9999)$$);
SELECT expect_fail('rider_verifications: invalid status (CHECK)',
  $$INSERT INTO rider_verifications(rider_id,document_reference,verification_status,reviewed_at) VALUES (6,'D','maybe',NOW())$$);
SELECT expect_fail('rider_verifications: rejected without reason (CHECK)',
  $$INSERT INTO rider_verifications(rider_id,document_reference,verification_status,reviewed_at) VALUES (6,'D','rejected',NOW())$$);
-- docking_stations
SELECT expect_fail('docking_stations: invalid status (CHECK)',
  $$INSERT INTO docking_stations(station_name,location_description,station_status) VALUES ('S','L','broken')$$);
SELECT expect_fail('docking_stations: latitude out of range (CHECK)',
  $$INSERT INTO docking_stations(station_name,location_description,latitude) VALUES ('S','L',95)$$);
-- bikes
SELECT expect_fail('bikes: duplicate qr_code (UNIQUE)',
  $$INSERT INTO bikes(qr_code) VALUES ('QR-BIKE-0001')$$);
SELECT expect_fail('bikes: station does not exist (FK)',
  $$INSERT INTO bikes(qr_code,current_station_id) VALUES ('QR-X',9999)$$);
SELECT expect_fail('bikes: invalid status (CHECK)',
  $$INSERT INTO bikes(qr_code,bike_status) VALUES ('QR-Y','flying')$$);
-- pricing_plans
SELECT expect_fail('pricing_plans: duplicate plan_name (UNIQUE)',
  $$INSERT INTO pricing_plans(plan_name,plan_type,price) VALUES ('Day Pass','day_pass',10)$$);
SELECT expect_fail('pricing_plans: negative price (CHECK)',
  $$INSERT INTO pricing_plans(plan_name,plan_type,price) VALUES ('Neg','day_pass',-5)$$);
SELECT expect_fail('pricing_plans: invalid plan_type (CHECK)',
  $$INSERT INTO pricing_plans(plan_name,plan_type,price) VALUES ('Bad','lifetime',5)$$);
SELECT expect_fail('pricing_plans: 4-letter currency code (CHAR(3))',
  $$INSERT INTO pricing_plans(plan_name,plan_type,price,currency_code) VALUES ('Cur','day_pass',5,'EGPX')$$);
-- rentals
SELECT expect_fail('rentals: rider does not exist (FK)',
  $$INSERT INTO rentals(rider_id,bike_id,pricing_plan_id) VALUES (9999,1,1)$$);
SELECT expect_fail('rentals: bike does not exist (FK)',
  $$INSERT INTO rentals(rider_id,bike_id,pricing_plan_id) VALUES (3,9999,1)$$);
SELECT expect_fail('rentals: pricing plan does not exist (FK)',
  $$INSERT INTO rentals(rider_id,bike_id,pricing_plan_id) VALUES (3,1,9999)$$);
SELECT expect_fail('rentals: end station does not exist (FK)',
  $$INSERT INTO rentals(rider_id,bike_id,pricing_plan_id,end_station_id) VALUES (3,1,1,9999)$$);
SELECT expect_fail('rentals: end_time before start_time (CHECK)',
  $$INSERT INTO rentals(rider_id,bike_id,pricing_plan_id,rental_status,start_time,end_time,total_cost) VALUES (3,1,1,'completed',NOW(),NOW()-INTERVAL '1 hour',1)$$);
SELECT expect_fail('rentals: negative total_cost (CHECK)',
  $$INSERT INTO rentals(rider_id,bike_id,pricing_plan_id,total_cost) VALUES (3,1,1,-1)$$);
SELECT expect_fail('rentals: invalid status (CHECK)',
  $$INSERT INTO rentals(rider_id,bike_id,pricing_plan_id,rental_status) VALUES (3,1,1,'lost')$$);
SELECT expect_fail('rentals: cancelled without cancelled_at (CHECK)',
  $$INSERT INTO rentals(rider_id,bike_id,pricing_plan_id,rental_status) VALUES (3,1,1,'cancelled')$$);
-- damage_reports
SELECT expect_fail('damage_reports: bike does not exist (FK)',
  $$INSERT INTO damage_reports(bike_id,rider_id,description) VALUES (9999,3,'x')$$);
SELECT expect_fail('damage_reports: rider does not exist (FK)',
  $$INSERT INTO damage_reports(bike_id,rider_id,description) VALUES (1,9999,'x')$$);
SELECT expect_fail('damage_reports: NULL description (NOT NULL)',
  $$INSERT INTO damage_reports(bike_id,rider_id,description) VALUES (1,3,NULL)$$);
SELECT expect_fail('damage_reports: invalid status (CHECK)',
  $$INSERT INTO damage_reports(bike_id,rider_id,description,report_status) VALUES (1,3,'x','closed')$$);
-- notifications
SELECT expect_fail('notifications: user does not exist (FK)',
  $$INSERT INTO notifications(user_id,notification_type,message) VALUES (9999,'system','x')$$);
SELECT expect_fail('notifications: rental does not exist (FK)',
  $$INSERT INTO notifications(user_id,rental_id,notification_type,message) VALUES (3,9999,'system','x')$$);
SELECT expect_fail('notifications: invalid type (CHECK)',
  $$INSERT INTO notifications(user_id,notification_type,message) VALUES (3,'spam','x')$$);

-- ------------------- DELETE-BEHAVIOUR (referential actions) -------------------
-- bike 5 has rentals AND damage reports: remove its rentals first so only the damage FK can block it
SELECT expect_fail('delete bike that has damage reports -> RESTRICT',
  $$DELETE FROM rentals WHERE bike_id = 5; DELETE FROM bikes WHERE bike_id = 5$$);
SELECT expect_fail('delete user who has rentals -> blocked (no cascade)',
  $$DELETE FROM users WHERE user_id = 3$$);
SELECT expect_fail('delete station still used by bikes -> blocked',
  $$DELETE FROM docking_stations WHERE station_id = 1$$);

-- CASCADE and SET NULL are checked by really deleting, then looking at the result
-- (these run last; the final ROLLBACK restores everything)
DELETE FROM users WHERE user_id = 6;
INSERT INTO test_results(kind,label,outcome,detail)
SELECT 'delete', 'delete user 6 -> its verifications and notifications are CASCADE-deleted',
  CASE WHEN (SELECT COUNT(*) FROM rider_verifications WHERE rider_id = 6) = 0
        AND (SELECT COUNT(*) FROM notifications WHERE user_id = 6) = 0 THEN 'PASS' ELSE 'FAIL' END, NULL;

DELETE FROM rentals WHERE rental_id = 1;
INSERT INTO test_results(kind,label,outcome,detail)
SELECT 'delete', 'delete rental 1 -> its 3 notifications are kept with rental_id SET NULL',
  CASE WHEN (SELECT COUNT(*) FROM notifications WHERE user_id = 3 AND rental_id IS NULL
             AND notification_type IN ('rental_started','rental_ended','payment')) = 3 THEN 'PASS' ELSE 'FAIL' END, NULL;

-- ------------------------------- RESULTS -------------------------------
SELECT kind, outcome, label, COALESCE(left(detail,90),'') AS db_response
FROM test_results ORDER BY id;

SELECT outcome, COUNT(*) FROM test_results GROUP BY outcome ORDER BY outcome;

ROLLBACK;
