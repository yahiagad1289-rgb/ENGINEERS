-- Checks that the created database matches the ERD. Run after 01_schema.sql.
-- Part A: every ERD column exists with the ERD data type (and nothing extra).
-- Part B: every ERD relationship exists as a foreign key.
-- Part C: row counts of the 8 tables.
-- Part A and B must return ZERO rows in the "problems" queries.

-- ---------- Part A: columns -------------------------------------------------
CREATE TEMP TABLE erd_columns (tbl TEXT, col TEXT, dtype TEXT, nullable BOOLEAN);
INSERT INTO erd_columns VALUES
 ('users','user_id','bigint',false), ('users','full_name','character varying',false),
 ('users','email','character varying',false), ('users','password_hash','text',false),
 ('users','role','character varying',false), ('users','created_at','timestamp with time zone',false),
 ('users','updated_at','timestamp with time zone',false),

 ('rider_verifications','verification_id','bigint',false), ('rider_verifications','rider_id','bigint',false),
 ('rider_verifications','document_reference','text',false), ('rider_verifications','verification_status','character varying',false),
 ('rider_verifications','rejection_reason','text',true), ('rider_verifications','submitted_at','timestamp with time zone',false),
 ('rider_verifications','reviewed_at','timestamp with time zone',true), ('rider_verifications','reviewed_by_admin_id','bigint',true),

 ('bikes','bike_id','bigint',false), ('bikes','qr_code','character varying',false),
 ('bikes','bike_status','character varying',false), ('bikes','current_station_id','bigint',true),
 ('bikes','added_at','timestamp with time zone',false), ('bikes','updated_at','timestamp with time zone',false),

 ('docking_stations','station_id','bigint',false), ('docking_stations','station_name','character varying',false),
 ('docking_stations','location_description','text',false), ('docking_stations','latitude','numeric',true),
 ('docking_stations','longitude','numeric',true), ('docking_stations','station_status','character varying',false),
 ('docking_stations','created_at','timestamp with time zone',false),

 ('pricing_plans','pricing_plan_id','bigint',false), ('pricing_plans','plan_name','character varying',false),
 ('pricing_plans','plan_type','character varying',false), ('pricing_plans','price','numeric',false),
 ('pricing_plans','currency_code','character',false), ('pricing_plans','duration_minutes','integer',true),
 ('pricing_plans','is_active','boolean',false), ('pricing_plans','created_at','timestamp with time zone',false),

 ('rentals','rental_id','bigint',false), ('rentals','rider_id','bigint',false), ('rentals','bike_id','bigint',false),
 ('rentals','pricing_plan_id','bigint',false), ('rentals','start_station_id','bigint',true),
 ('rentals','end_station_id','bigint',true), ('rentals','rental_status','character varying',false),
 ('rentals','requested_at','timestamp with time zone',false), ('rentals','start_time','timestamp with time zone',true),
 ('rentals','end_time','timestamp with time zone',true), ('rentals','cancelled_at','timestamp with time zone',true),
 ('rentals','total_cost','numeric',true),

 ('damage_reports','report_id','bigint',false), ('damage_reports','bike_id','bigint',false),
 ('damage_reports','rider_id','bigint',false), ('damage_reports','description','text',false),
 ('damage_reports','report_status','character varying',false), ('damage_reports','reported_at','timestamp with time zone',false),
 ('damage_reports','reviewed_by_admin_id','bigint',true), ('damage_reports','reviewed_at','timestamp with time zone',true),

 ('notifications','notification_id','bigint',false), ('notifications','user_id','bigint',false),
 ('notifications','rental_id','bigint',true), ('notifications','notification_type','character varying',false),
 ('notifications','message','text',false), ('notifications','created_at','timestamp with time zone',false),
 ('notifications','read_at','timestamp with time zone',true);

\echo '=== A. Column problems (expect 0 rows) ==='
SELECT e.tbl, e.col, 'missing or wrong type/nullability' AS problem, e.dtype AS erd_type, c.data_type AS db_type
FROM erd_columns e
LEFT JOIN information_schema.columns c
  ON c.table_schema='public' AND c.table_name=e.tbl AND c.column_name=e.col
WHERE c.column_name IS NULL OR c.data_type <> e.dtype OR (c.is_nullable='YES') <> e.nullable
UNION ALL
SELECT c.table_name, c.column_name, 'extra column not in ERD', NULL, c.data_type
FROM information_schema.columns c
LEFT JOIN erd_columns e ON e.tbl=c.table_name AND e.col=c.column_name
WHERE c.table_schema='public' AND e.col IS NULL;

-- ---------- Part B: relationships -------------------------------------------
CREATE TEMP TABLE erd_fks (child TEXT, child_col TEXT, parent TEXT, parent_col TEXT);
INSERT INTO erd_fks VALUES
 ('rider_verifications','rider_id','users','user_id'),
 ('rider_verifications','reviewed_by_admin_id','users','user_id'),
 ('bikes','current_station_id','docking_stations','station_id'),
 ('rentals','rider_id','users','user_id'),
 ('rentals','bike_id','bikes','bike_id'),
 ('rentals','pricing_plan_id','pricing_plans','pricing_plan_id'),
 ('rentals','start_station_id','docking_stations','station_id'),
 ('rentals','end_station_id','docking_stations','station_id'),
 ('damage_reports','bike_id','bikes','bike_id'),
 ('damage_reports','rider_id','users','user_id'),
 ('damage_reports','reviewed_by_admin_id','users','user_id'),
 ('notifications','user_id','users','user_id'),
 ('notifications','rental_id','rentals','rental_id');

CREATE TEMP VIEW db_fks AS
SELECT cl.relname AS child, ca.attname AS child_col, pl.relname AS parent, pa.attname AS parent_col,
       con.conname, con.confdeltype
FROM pg_constraint con
JOIN pg_class cl ON cl.oid = con.conrelid
JOIN pg_class pl ON pl.oid = con.confrelid
JOIN pg_attribute ca ON ca.attrelid = con.conrelid  AND ca.attnum = con.conkey[1]
JOIN pg_attribute pa ON pa.attrelid = con.confrelid AND pa.attnum = con.confkey[1]
WHERE con.contype = 'f' AND cl.relnamespace = 'public'::regnamespace;

\echo '=== B. Foreign-key problems (expect 0 rows) ==='
SELECT e.child, e.child_col, e.parent, 'ERD relationship missing in DB' AS problem
FROM erd_fks e LEFT JOIN db_fks d
  ON d.child=e.child AND d.child_col=e.child_col AND d.parent=e.parent AND d.parent_col=e.parent_col
WHERE d.conname IS NULL
UNION ALL
SELECT d.child, d.child_col, d.parent, 'FK in DB not in ERD'
FROM db_fks d LEFT JOIN erd_fks e
  ON d.child=e.child AND d.child_col=e.child_col AND d.parent=e.parent AND d.parent_col=e.parent_col
WHERE e.child IS NULL;

\echo '=== B2. All foreign keys in the database (with ON DELETE action) ==='
SELECT child, child_col, parent, parent_col, conname,
       CASE confdeltype WHEN 'a' THEN 'NO ACTION' WHEN 'r' THEN 'RESTRICT' WHEN 'c' THEN 'CASCADE'
                        WHEN 'n' THEN 'SET NULL' ELSE confdeltype::text END AS on_delete
FROM db_fks ORDER BY child, child_col;

-- ---------- Part C: tables and rows ---------------------------------------
\echo '=== C. Tables present and row counts (expect 8 tables, all > 0 after sample data) ==='
SELECT 'users' AS tbl, COUNT(*) AS rows FROM users UNION ALL
SELECT 'rider_verifications', COUNT(*) FROM rider_verifications UNION ALL
SELECT 'docking_stations', COUNT(*) FROM docking_stations UNION ALL
SELECT 'bikes', COUNT(*) FROM bikes UNION ALL
SELECT 'pricing_plans', COUNT(*) FROM pricing_plans UNION ALL
SELECT 'rentals', COUNT(*) FROM rentals UNION ALL
SELECT 'damage_reports', COUNT(*) FROM damage_reports UNION ALL
SELECT 'notifications', COUNT(*) FROM notifications;

\echo '=== D. Orphan check across all FKs (expect all zero) ==='
SELECT 'rider_verifications.rider_id' AS fk, COUNT(*) AS orphans FROM rider_verifications t LEFT JOIN users p ON p.user_id=t.rider_id WHERE p.user_id IS NULL
UNION ALL SELECT 'rider_verifications.reviewed_by_admin_id', COUNT(*) FROM rider_verifications t LEFT JOIN users p ON p.user_id=t.reviewed_by_admin_id WHERE t.reviewed_by_admin_id IS NOT NULL AND p.user_id IS NULL
UNION ALL SELECT 'bikes.current_station_id', COUNT(*) FROM bikes t LEFT JOIN docking_stations p ON p.station_id=t.current_station_id WHERE t.current_station_id IS NOT NULL AND p.station_id IS NULL
UNION ALL SELECT 'rentals.rider_id', COUNT(*) FROM rentals t LEFT JOIN users p ON p.user_id=t.rider_id WHERE p.user_id IS NULL
UNION ALL SELECT 'rentals.bike_id', COUNT(*) FROM rentals t LEFT JOIN bikes p ON p.bike_id=t.bike_id WHERE p.bike_id IS NULL
UNION ALL SELECT 'rentals.pricing_plan_id', COUNT(*) FROM rentals t LEFT JOIN pricing_plans p ON p.pricing_plan_id=t.pricing_plan_id WHERE p.pricing_plan_id IS NULL
UNION ALL SELECT 'rentals.start_station_id', COUNT(*) FROM rentals t LEFT JOIN docking_stations p ON p.station_id=t.start_station_id WHERE t.start_station_id IS NOT NULL AND p.station_id IS NULL
UNION ALL SELECT 'rentals.end_station_id', COUNT(*) FROM rentals t LEFT JOIN docking_stations p ON p.station_id=t.end_station_id WHERE t.end_station_id IS NOT NULL AND p.station_id IS NULL
UNION ALL SELECT 'damage_reports.bike_id', COUNT(*) FROM damage_reports t LEFT JOIN bikes p ON p.bike_id=t.bike_id WHERE p.bike_id IS NULL
UNION ALL SELECT 'damage_reports.rider_id', COUNT(*) FROM damage_reports t LEFT JOIN users p ON p.user_id=t.rider_id WHERE p.user_id IS NULL
UNION ALL SELECT 'damage_reports.reviewed_by_admin_id', COUNT(*) FROM damage_reports t LEFT JOIN users p ON p.user_id=t.reviewed_by_admin_id WHERE t.reviewed_by_admin_id IS NOT NULL AND p.user_id IS NULL
UNION ALL SELECT 'notifications.user_id', COUNT(*) FROM notifications t LEFT JOIN users p ON p.user_id=t.user_id WHERE p.user_id IS NULL
UNION ALL SELECT 'notifications.rental_id', COUNT(*) FROM notifications t LEFT JOIN rentals p ON p.rental_id=t.rental_id WHERE t.rental_id IS NOT NULL AND p.rental_id IS NULL;
