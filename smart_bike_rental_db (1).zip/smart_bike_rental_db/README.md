# Smart Bike Rental App – Database (PostgreSQL)

Integrated database for the Smart Bike Rental App: 8 tables, aligned to the team ERD.

## Files

| File | Purpose |
|---|---|
| `01_schema.sql` | Combined `CREATE TABLE` script for all 8 tables, in foreign-key order |
| `02_sample_data.sql` | Sample rows for every table (6 users, 4 verifications, 4 stations, 6 bikes, 4 plans, 5 rentals, 3 damage reports, 6 notifications) |
| `03_tests.sql` | 44 tests: valid inserts, invalid inserts, delete behaviour. Runs in a transaction and rolls back |
| `04_verify_erd.sql` | Checks the database against the ERD (columns, types, nullability, foreign keys, orphan rows) |
| `run_all.sql` | Runs everything in the right order |
| `test_output.txt` | Saved output of a full run |

## How to run

Requires PostgreSQL 13+ (tested on 16).

```bash
createdb bikerental
psql -d bikerental -f run_all.sql
```

Expected result: no errors, `PASS 44`, and both "problems" queries in section A and B of the ERD check return 0 rows.
`01_schema.sql` drops and recreates all tables, so it is safe to re-run.

## Table creation order (foreign-key dependencies)

`users` → `rider_verifications` · `docking_stations` → `bikes` · `pricing_plans` → `rentals` → `damage_reports`, `notifications`

## Relationships and delete rules

| Child column | Parent | ON DELETE | Reason |
|---|---|---|---|
| rider_verifications.rider_id | users | CASCADE | verification means nothing without the rider |
| rider_verifications.reviewed_by_admin_id | users | SET NULL | keep the record if the admin account is removed |
| bikes.current_station_id | docking_stations | NO ACTION | a station in use cannot be deleted; NULL while the bike is rented |
| rentals.rider_id / bike_id / pricing_plan_id / start_station_id / end_station_id | users / bikes / pricing_plans / docking_stations | NO ACTION | rental history must not be lost |
| damage_reports.bike_id, rider_id | bikes, users | RESTRICT | keep damage history |
| damage_reports.reviewed_by_admin_id | users | SET NULL | keep the report |
| notifications.user_id | users | CASCADE | notifications belong to the user |
| notifications.rental_id | rentals | SET NULL | keep the message if the rental is removed |

## Traceability table

Each ERD entity → who wrote it → what was changed to integrate it → how it is tested.

| ERD entity | Owner | Source script | Integration changes | Key constraints | Sample rows | Tests (in `03_tests.sql`) |
|---|---|---|---|---|---|---|
| USERS | Person 1 | **none supplied** | Table written from the ERD (rest of the schema depends on it) | PK, UNIQUE email, role ∈ {rider, admin} | 6 | duplicate email, bad role, NULL email |
| RIDER_VERIFICATIONS | Person 1 | `database & user tables.sql` | `user_id`→`rider_id`; `document_type`+`document_number`→`document_reference`; `verified_at`→`reviewed_at`; added `rejection_reason`, `reviewed_by_admin_id`; INTEGER→BIGINT; removed stray SELECT queries | status ∈ {pending, approved, rejected}; rejected needs a reason; reviewed needs `reviewed_at` | 4 | missing rider FK, missing admin FK, bad status, rejected without reason; CASCADE on user delete |
| DOCKING_STATIONS | Person 2 | `01_create_tables_person2.sql` | `address`→`location_description`; `status`→`station_status`; `station_name` 100→120; **removed `total_docks`** (not in ERD); added lat/long range checks | status ∈ {active, inactive, maintenance} | 4 | bad status, latitude 95 |
| BIKES | Person 2 | `01_create_tables_person2.sql` | `bike_code`→`qr_code` (255); `status`→`bike_status`; `created_at`→`added_at`; added `updated_at`; **removed `bike_type`** (not in ERD) | UNIQUE qr_code, status ∈ {available, rented, maintenance, damaged} | 6 | duplicate QR, missing station FK, bad status |
| PRICING_PLANS | Person 3 | `person3_rentals_pricing.sql` | **Rewritten**: MySQL → PostgreSQL; `plan_id`→`pricing_plan_id`; `unlock_fee`/`price_per_minute`/`daily_cap` replaced by `plan_type`, `price`, `currency_code`, `duration_minutes`, `created_at` as in ERD | UNIQUE name, price ≥ 0, plan_type check | 4 | duplicate name, negative price, bad type, 4-letter currency |
| RENTALS | Person 3 | `person3_rentals_pricing.sql` | **Rewritten**: MySQL → PostgreSQL; `user_id`→`rider_id`; `plan_id`→`pricing_plan_id`; `status`→`rental_status`; added `requested_at`, `cancelled_at`; start station now nullable; INT→BIGINT, DATETIME→TIMESTAMPTZ | status ∈ {requested, active, completed, cancelled}; end > start; cost ≥ 0; cancelled ⇔ `cancelled_at` set | 5 | 4 missing-FK cases, end before start, negative cost, bad status, cancelled without timestamp |
| DAMAGE_REPORTS | Person 4 | `person4_reports_notifications.sql.txt` | `damage_report_id`→`report_id`; `reported_by`→`rider_id`; `status`→`report_status`; **removed `rental_id`, `severity`, `resolved_at`** (not in ERD); added `reviewed_by_admin_id`, `reviewed_at` | status ∈ {open, in_review, resolved}; RESTRICT deletes | 3 | missing bike/rider FK, NULL description, bad status; RESTRICT on bike delete |
| NOTIFICATIONS | Person 4 | `person4_reports_notifications.sql.txt` | `type`→`notification_type`; `is_read` boolean → `read_at` timestamp; SERIAL→BIGINT identity | type ∈ {rental_started, rental_ended, payment, damage_update, system} | 6 | missing user/rental FK, bad type; SET NULL on rental delete |

## Decisions and assumptions to confirm with the team

1. **The ERD was treated as the source of truth.** Where a teammate's script and the ERD disagreed, the ERD won. Columns that existed only in a script (`total_docks`, `bike_type`, `unlock_fee`, `price_per_minute`, `daily_cap`, `severity`, `damage_reports.rental_id`) were dropped. If the team wants any of them, they should be added to the ERD first, then to `01_schema.sql`.
2. **Allowed values the ERD does not list** were taken from teammates' scripts where available. `users.role` (`rider`/`admin`), `rentals.rental_status` (adds `requested`, implied by `requested_at`) and `pricing_plans.plan_type` (`pay_per_ride`/`day_pass`/`monthly`) are our assumptions.
3. **The ERD shows `start_time / end_time` on one line** in RENTALS; they are implemented as two separate columns.
4. **Admin-only reviewers** (`reviewed_by_admin_id`) point to `users`, but the database does not enforce that the referenced user has `role = 'admin'`. A trigger could add this; it is not included.
5. Default currency is `EGP`.
6. Money uses `NUMERIC(10,2)`, timestamps use `TIMESTAMPTZ`, ids use `BIGINT GENERATED ALWAYS AS IDENTITY`, as in the ERD.
