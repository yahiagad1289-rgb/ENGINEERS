-- Runs everything in order. Usage:  psql -d bikerental -f run_all.sql
\set ON_ERROR_STOP on
\i 01_schema.sql
\i 02_sample_data.sql
\i 04_verify_erd.sql
\i 03_tests.sql
